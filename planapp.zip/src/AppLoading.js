import React from 'react'
import { View, Text } from 'react-native'

const AppLoading = () => (
  <View>
    <Text>Loading...</Text>
  </View>
)

export default AppLoading