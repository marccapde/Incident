
const SCREENS = {
  MyPlans: 'MY_PLANS_SCREEN',
  PlanDetail: 'PLAN_DETAIL_SCREEN'
}

export { SCREENS }