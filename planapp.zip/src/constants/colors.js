
const COLORS = {
  primary: '#993aab',
  primaryText: 'white',
  text: 'black',
  background: 'white',
  tabIcon: 'rgba(0, 0, 0, 0.3)'
}

export { COLORS }