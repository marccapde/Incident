
export const MY_PLANS_ACTIONS = {
  Requested: 'MY_PLANS_REQUESTED',
  Error: 'MY_PLANS_ERROR_RECEIVED',
  Received: 'MY_PLANS_RECEIVED'
}