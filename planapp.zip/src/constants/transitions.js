
export const TRANSITIONS = {
  SharedElement: 'SHARED_ELEMENT'
}